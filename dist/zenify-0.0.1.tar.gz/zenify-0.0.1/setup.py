from setuptools import setup

setup(
    name='zenify',
    version='0.0.1',
    description='data scraping framework',
    packages=['zenify']
)